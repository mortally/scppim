package org.srg.scpp_im.strategy;

public class SAA_SCD extends SelfConfirmingDistributionPricePrediction
{
	private static final long serialVersionUID = 100L;
	
	public SAA_SCD(int index)
	{
		super(index);
	}

}
